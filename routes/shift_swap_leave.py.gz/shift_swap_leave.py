"""
Shift Swap & Leave Management Routes
API endpoints for managing shift swaps and leave requests
"""

from flask import Blueprint, request, jsonify, render_template, flash, redirect, url_for
from flask_login import login_required, current_user
from datetime import datetime, date
from services.shift_swap_leave_service import shift_swap_leave_service
from models.models import User, ShiftRoster, TeamMember, db
from models.shift_swap_leave import ShiftSwapRequest, LeaveRequest
import logging

logger = logging.getLogger(__name__)

# Create blueprint
shift_swap_leave_bp = Blueprint('shift_swap_leave', __name__, url_prefix='/shift-management')

@shift_swap_leave_bp.route('/dashboard')
@login_required
def dashboard():
    """Main dashboard for shift management"""
    try:
        # Get user's requests
        user_requests = shift_swap_leave_service.get_user_requests(current_user.id)
        
        # Get pending requests for approval (if user is admin)
        pending_requests = {'success': True, 'swap_requests': [], 'leave_requests': []}
        if current_user.role in ['super_admin', 'account_admin', 'team_admin']:
            pending_requests = shift_swap_leave_service.get_pending_requests_for_approval(current_user.id)
        
        return render_template('shift_management/dashboard.html',
                             user_requests=user_requests,
                             pending_requests=pending_requests,
                             current_user=current_user)
    except Exception as e:
        logger.error(f"Error loading shift management dashboard: {str(e)}")
        flash('Error loading dashboard', 'error')
        return redirect('/')

@shift_swap_leave_bp.route('/swap/request', methods=['GET', 'POST'])
@login_required
def request_swap():
    """Request a shift swap"""
    if request.method == 'GET':
        # Show swap request form
        return render_template('shift_management/request_swap.html', current_user=current_user)
    
    try:
        data = request.get_json() if request.is_json else request.form.to_dict()
        
        # Validate required fields
        required_fields = ['swap_with_id', 'original_date', 'original_shift_code', 
                          'swap_date', 'swap_shift_code', 'reason']
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({'success': False, 'error': f'Missing required field: {field}'}), 400
        
        # Parse dates
        try:
            original_date = datetime.strptime(data['original_date'], '%Y-%m-%d').date()
            swap_date = datetime.strptime(data['swap_date'], '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'success': False, 'error': 'Invalid date format'}), 400
        
        # Create the swap request
        result = shift_swap_leave_service.create_shift_swap_request(
            requester_id=current_user.id,
            swap_with_id=int(data['swap_with_id']),
            original_date=original_date,
            original_shift_code=data['original_shift_code'],
            swap_date=swap_date,
            swap_shift_code=data['swap_shift_code'],
            reason=data['reason']
        )
        
        if result['success']:
            if request.is_json:
                return jsonify(result)
            else:
                flash('Shift swap request submitted successfully!', 'success')
                return redirect(url_for('shift_swap_leave.dashboard'))
        else:
            if request.is_json:
                return jsonify(result), 400
            else:
                flash(f'Error: {result["error"]}', 'error')
                return render_template('shift_management/request_swap.html', current_user=current_user)
    
    except Exception as e:
        logger.error(f"Error creating swap request: {str(e)}")
        error_msg = 'An error occurred while processing your request'
        if request.is_json:
            return jsonify({'success': False, 'error': error_msg}), 500
        else:
            flash(error_msg, 'error')
            return render_template('shift_management/request_swap.html', current_user=current_user)

@shift_swap_leave_bp.route('/leave/request', methods=['GET', 'POST'])
@login_required
def request_leave():
    """Request leave"""
    if request.method == 'GET':
        # Show leave request form
        return render_template('shift_management/request_leave.html', current_user=current_user)
    
    try:
        data = request.get_json() if request.is_json else request.form.to_dict()
        
        # Validate required fields
        required_fields = ['leave_type', 'leave_date', 'shift_code']
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({'success': False, 'error': f'Missing required field: {field}'}), 400
        
        # Parse date
        try:
            leave_date = datetime.strptime(data['leave_date'], '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'success': False, 'error': 'Invalid date format'}), 400
        
        # Create the leave request
        result = shift_swap_leave_service.create_leave_request(
            requester_id=current_user.id,
            leave_type=data['leave_type'],
            leave_date=leave_date,
            shift_code=data['shift_code'],
            reason=data.get('reason', '')
        )
        
        if result['success']:
            if request.is_json:
                return jsonify(result)
            else:
                flash('Leave request submitted successfully!', 'success')
                return redirect(url_for('shift_swap_leave.dashboard'))
        else:
            if request.is_json:
                return jsonify(result), 400
            else:
                flash(f'Error: {result["error"]}', 'error')
                return render_template('shift_management/request_leave.html', current_user=current_user)
    
    except Exception as e:
        logger.error(f"Error creating leave request: {str(e)}")
        error_msg = 'An error occurred while processing your request'
        if request.is_json:
            return jsonify({'success': False, 'error': error_msg}), 500
        else:
            flash(error_msg, 'error')
            return render_template('shift_management/request_leave.html', current_user=current_user)

@shift_swap_leave_bp.route('/api/eligible-partners')
@login_required
def get_eligible_partners():
    """Get eligible team members for shift swapping - STRICT team and account isolation"""
    try:
        # STRICT REQUIREMENT: Current user must have team_id and account_id
        if not current_user.team_id or not current_user.account_id:
            return jsonify({
                'success': False, 
                'error': 'User must be assigned to a team and account to find eligible partners'
            }), 403
        
        request_date_str = request.args.get('date')
        shift_code = request.args.get('shift_code')
        
        if not request_date_str or not shift_code:
            return jsonify({'success': False, 'error': 'Missing date or shift_code parameter'}), 400
        
        try:
            request_date = datetime.strptime(request_date_str, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'success': False, 'error': 'Invalid date format'}), 400
        
        logger.info(f"Finding eligible partners for user {current_user.username} (team_id={current_user.team_id}, account_id={current_user.account_id})")
        
        partners = shift_swap_leave_service.get_eligible_swap_partners(
            current_user.id, request_date, shift_code
        )
        
        return jsonify({'success': True, 'partners': partners})
    
    except Exception as e:
        logger.error(f"Error getting eligible partners: {str(e)}")
        return jsonify({'success': False, 'error': 'An error occurred'}), 500

@shift_swap_leave_bp.route('/api/user-schedule')
@login_required
def get_user_schedule():
    """Get user's upcoming schedule - STRICT team and account isolation"""
    try:
        user_id = request.args.get('user_id', current_user.id, type=int)
        
        # STRICT REQUIREMENT: Current user must have team_id and account_id
        if not current_user.team_id or not current_user.account_id:
            return jsonify({'success': False, 'error': 'User must be assigned to a team and account'}), 403
        
        # Get the requested user
        user = User.query.get(user_id)
        if not user:
            return jsonify({'success': False, 'error': 'User not found'}), 404
        
        # STRICT ISOLATION: Can only view schedules of users in same team and account
        if user.team_id != current_user.team_id or user.account_id != current_user.account_id:
            logger.warning(f"User {current_user.username} attempted to access schedule of user {user.username} from different team/account")
            return jsonify({'success': False, 'error': 'Access denied - can only view schedules within your team'}), 403
        
        team_member = TeamMember.query.filter_by(
            name=user.username,
            account_id=current_user.account_id,  # Use current user's account_id for extra security
            team_id=current_user.team_id         # Use current user's team_id for extra security
        ).first()
        
        if not team_member:
            return jsonify({'success': True, 'schedule': []})
        
        # Get upcoming shifts (next 30 days) - STRICT filtering
        from datetime import timedelta
        start_date = date.today()
        end_date = start_date + timedelta(days=30)
        
        shifts = ShiftRoster.query.filter(
            ShiftRoster.team_member_id == team_member.id,
            ShiftRoster.date >= start_date,
            ShiftRoster.date <= end_date,
            ShiftRoster.account_id == current_user.account_id,  # STRICT: Same account as current user
            ShiftRoster.team_id == current_user.team_id         # STRICT: Same team as current user
        ).order_by(ShiftRoster.date).all()
        
        schedule = [{
            'date': shift.date.isoformat(),
            'shift_code': shift.shift_code,
            'day_of_week': shift.date.strftime('%A')
        } for shift in shifts]
        
        return jsonify({'success': True, 'schedule': schedule})
    
    except Exception as e:
        logger.error(f"Error getting user schedule: {str(e)}")
        return jsonify({'success': False, 'error': 'An error occurred'}), 500

@shift_swap_leave_bp.route('/admin/approve-swap/<int:request_id>', methods=['POST'])
@login_required
def approve_swap_request(request_id):
    """Approve a shift swap request"""
    if current_user.role not in ['super_admin', 'account_admin', 'team_admin']:
        return jsonify({'success': False, 'error': 'Insufficient permissions'}), 403
    
    try:
        data = request.get_json() if request.is_json else request.form.to_dict()
        comments = data.get('comments', '')
        
        result = shift_swap_leave_service.approve_swap_request(
            request_id=request_id,
            approver_id=current_user.id,
            comments=comments
        )
        
        if request.is_json:
            return jsonify(result)
        else:
            if result['success']:
                flash(result['message'], 'success')
            else:
                flash(f'Error: {result["error"]}', 'error')
            return redirect(url_for('shift_swap_leave.dashboard'))
    
    except Exception as e:
        logger.error(f"Error approving swap request: {str(e)}")
        error_msg = 'An error occurred while processing the approval'
        if request.is_json:
            return jsonify({'success': False, 'error': error_msg}), 500
        else:
            flash(error_msg, 'error')
            return redirect(url_for('shift_swap_leave.dashboard'))

@shift_swap_leave_bp.route('/admin/approve-leave/<int:request_id>', methods=['POST'])
@login_required
def approve_leave_request(request_id):
    """Approve a leave request"""
    if current_user.role not in ['super_admin', 'account_admin', 'team_admin']:
        return jsonify({'success': False, 'error': 'Insufficient permissions'}), 403
    
    try:
        data = request.get_json() if request.is_json else request.form.to_dict()
        comments = data.get('comments', '')
        covered_by_id = data.get('covered_by_id')
        if covered_by_id:
            covered_by_id = int(covered_by_id)
        
        result = shift_swap_leave_service.approve_leave_request(
            request_id=request_id,
            approver_id=current_user.id,
            comments=comments,
            covered_by_id=covered_by_id
        )
        
        if request.is_json:
            return jsonify(result)
        else:
            if result['success']:
                flash(result['message'], 'success')
            else:
                flash(f'Error: {result["error"]}', 'error')
            return redirect(url_for('shift_swap_leave.dashboard'))
    
    except Exception as e:
        logger.error(f"Error approving leave request: {str(e)}")
        error_msg = 'An error occurred while processing the approval'
        if request.is_json:
            return jsonify({'success': False, 'error': error_msg}), 500
        else:
            flash(error_msg, 'error')
            return redirect(url_for('shift_swap_leave.dashboard'))

@shift_swap_leave_bp.route('/admin/reject-swap/<int:request_id>', methods=['POST'])
@login_required
def reject_swap_request(request_id):
    """Reject a shift swap request"""
    if current_user.role not in ['super_admin', 'account_admin', 'team_admin']:
        return jsonify({'success': False, 'error': 'Insufficient permissions'}), 403
    
    try:
        data = request.get_json() if request.is_json else request.form.to_dict()
        comments = data.get('comments', '')
        
        if not comments:
            error_msg = 'Rejection reason is required'
            if request.is_json:
                return jsonify({'success': False, 'error': error_msg}), 400
            else:
                flash(error_msg, 'error')
                return redirect(url_for('shift_swap_leave.dashboard'))
        
        result = shift_swap_leave_service.reject_request(
            request_type='swap',
            request_id=request_id,
            approver_id=current_user.id,
            comments=comments
        )
        
        if request.is_json:
            return jsonify(result)
        else:
            if result['success']:
                flash(result['message'], 'success')
            else:
                flash(f'Error: {result["error"]}', 'error')
            return redirect(url_for('shift_swap_leave.dashboard'))
    
    except Exception as e:
        logger.error(f"Error rejecting swap request: {str(e)}")
        error_msg = 'An error occurred while processing the rejection'
        if request.is_json:
            return jsonify({'success': False, 'error': error_msg}), 500
        else:
            flash(error_msg, 'error')
            return redirect(url_for('shift_swap_leave.dashboard'))

@shift_swap_leave_bp.route('/admin/reject-leave/<int:request_id>', methods=['POST'])
@login_required
def reject_leave_request(request_id):
    """Reject a leave request"""
    if current_user.role not in ['super_admin', 'account_admin', 'team_admin']:
        return jsonify({'success': False, 'error': 'Insufficient permissions'}), 403
    
    try:
        data = request.get_json() if request.is_json else request.form.to_dict()
        comments = data.get('comments', '')
        
        if not comments:
            error_msg = 'Rejection reason is required'
            if request.is_json:
                return jsonify({'success': False, 'error': error_msg}), 400
            else:
                flash(error_msg, 'error')
                return redirect(url_for('shift_swap_leave.dashboard'))
        
        result = shift_swap_leave_service.reject_request(
            request_type='leave',
            request_id=request_id,
            approver_id=current_user.id,
            comments=comments
        )
        
        if request.is_json:
            return jsonify(result)
        else:
            if result['success']:
                flash(result['message'], 'success')
            else:
                flash(f'Error: {result["error"]}', 'error')
            return redirect(url_for('shift_swap_leave.dashboard'))
    
    except Exception as e:
        logger.error(f"Error rejecting leave request: {str(e)}")
        error_msg = 'An error occurred while processing the rejection'
        if request.is_json:
            return jsonify({'success': False, 'error': error_msg}), 500
        else:
            flash(error_msg, 'error')
            return redirect(url_for('shift_swap_leave.dashboard'))

@shift_swap_leave_bp.route('/api/my-requests')
@login_required
def get_my_requests():
    """Get current user's requests"""
    try:
        result = shift_swap_leave_service.get_user_requests(current_user.id)
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error getting user requests: {str(e)}")
        return jsonify({'success': False, 'error': 'An error occurred'}), 500

@shift_swap_leave_bp.route('/api/pending-approvals')
@login_required
def get_pending_approvals():
    """Get requests pending approval"""
    if current_user.role not in ['super_admin', 'account_admin', 'team_admin']:
        return jsonify({'success': False, 'error': 'Insufficient permissions'}), 403
    
    try:
        result = shift_swap_leave_service.get_pending_requests_for_approval(current_user.id)
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error getting pending approvals: {str(e)}")
        return jsonify({'success': False, 'error': 'An error occurred'}), 500

@shift_swap_leave_bp.route('/api/team-members')
@login_required
def get_team_members():
    """Get team members for dropdowns - STRICT team and account isolation"""
    try:
        logger.info(f"API team-members called by user: {current_user.username} (Team ID: {current_user.team_id}, Account ID: {current_user.account_id})")
        
        # STRICT REQUIREMENT: User must have both team_id and account_id assigned
        if not current_user.team_id or not current_user.account_id:
            logger.warning(f"User {current_user.username} missing team_id ({current_user.team_id}) or account_id ({current_user.account_id})")
            return jsonify({
                'success': False, 
                'error': 'User must be assigned to a team and account to view team members',
                'team_members': []
            })
        
        # Get team members from EXACTLY the same team and account, excluding current user
        team_members_query = User.query.filter(
            User.id != current_user.id,
            User.is_active == True,
            User.status == 'active',
            User.is_active == True,
            User.team_id == current_user.team_id,     # STRICT: Same team only
            User.account_id == current_user.account_id  # STRICT: Same account only
        )
        
        # Also get from TeamMember table for additional members (STRICT filtering)
        team_members_from_table = TeamMember.query.filter(
            TeamMember.team_id == current_user.team_id,
            TeamMember.account_id == current_user.account_id
        ).all()
        
        # Get users from User table
        users = team_members_query.limit(50).all()
        
        members_data = []
        
        # Add users from User table
        for user in users:
            members_data.append({
                'id': user.id,
                'username': user.username,
                'full_name': user.display_name,  # Use the property method
                'email': user.email if user.email else '',
                'source': 'user'
            })
        
        # Add team members from TeamMember table (if they don't have corresponding User records)
        existing_user_ids = {member['id'] for member in members_data}
        for tm in team_members_from_table:
            if tm.user_id and tm.user_id not in existing_user_ids:
                # Get the corresponding user record
                user = User.query.get(tm.user_id)
                if user and user.id != current_user.id:
                    members_data.append({
                        'id': user.id,
                        'username': user.username,
                        'full_name': user.display_name,
                        'email': user.email if user.email else tm.email,
                        'source': 'team_member'
                    })
            elif not tm.user_id:
                # TeamMember without corresponding User (legacy data)
                members_data.append({
                    'id': f"tm_{tm.id}",  # Use a special ID format
                    'username': tm.name,
                    'full_name': tm.name,
                    'email': tm.email,
                    'source': 'team_member_only'
                })
        
        # NO FALLBACK TO ACCOUNT LEVEL - Strict team isolation only
        # Users can only see their exact team members, no exceptions
        if not members_data:
            logger.info(f"No team members found for team_id={current_user.team_id}, account_id={current_user.account_id}")
            logger.info("STRICT ISOLATION: Not falling back to account level - team members only")
        
        logger.info(f"Returning {len(members_data)} team members from team_id={current_user.team_id}, account_id={current_user.account_id}")
        return jsonify({'success': True, 'team_members': members_data})
    
    except Exception as e:
        logger.error(f"Error getting team members: {str(e)}")
        return jsonify({'success': False, 'error': 'An error occurred'}), 500

@shift_swap_leave_bp.route('/api/shift-codes')
@login_required
def get_shift_codes():
    """Get available shift codes - STRICT team and account isolation"""
    try:
        logger.info(f"API shift-codes called by user: {current_user.username} (Team ID: {current_user.team_id}, Account ID: {current_user.account_id})")
        
        # STRICT REQUIREMENT: User must have both team_id and account_id assigned
        if not current_user.team_id or not current_user.account_id:
            logger.warning(f"User {current_user.username} missing team_id ({current_user.team_id}) or account_id ({current_user.account_id})")
            return jsonify({
                'success': False, 
                'error': 'User must be assigned to a team and account to view shift codes',
                'shift_codes': []
            })
        
        # Get shift codes ONLY from the user's specific team and account
        from sqlalchemy import text
        result = db.session.execute(
            text("SELECT DISTINCT shift_code FROM shift_roster WHERE shift_code IS NOT NULL AND team_id = :team_id AND account_id = :account_id"),
            {'team_id': current_user.team_id, 'account_id': current_user.account_id}
        )
        codes = [row[0] for row in result.fetchall() if row[0] not in ['LE', 'OFF', 'VL', 'HL']]  # Exclude leave codes
        
        logger.info(f"Returning {len(codes)} shift codes for team_id={current_user.team_id}, account_id={current_user.account_id}: {codes}")
        return jsonify({'success': True, 'shift_codes': codes})
    
    except Exception as e:
        logger.error(f"Error getting shift codes: {str(e)}")
        return jsonify({'success': False, 'error': 'An error occurred'}), 500

# Temporary test endpoints without login requirement
@shift_swap_leave_bp.route('/api/test-shift-codes')
def test_get_shift_codes():
    """Test endpoint for shift codes without authentication"""
    try:
        from sqlalchemy import text
        result = db.session.execute(
            text("SELECT DISTINCT shift_code FROM shift_roster WHERE shift_code IS NOT NULL")
        )
        codes = [row[0] for row in result.fetchall() if row[0] not in ['LE', 'OFF', 'VL', 'HL']]
        return jsonify({'success': True, 'shift_codes': codes, 'count': len(codes)})
    except Exception as e:
        logger.error(f"Error in test shift codes: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@shift_swap_leave_bp.route('/api/test-team-members')
def test_get_team_members():
    """Test endpoint for team members without authentication"""
    try:
        team_members = User.query.filter(
            User.first_name.isnot(None),
            User.last_name.isnot(None)
        ).limit(10).all()
        
        members_data = [{
            'id': member.id,
            'username': member.username,
            'full_name': f"{member.first_name} {member.last_name}",
            'email': member.email if member.email else ''
        } for member in team_members]
        
        return jsonify({'success': True, 'team_members': members_data, 'count': len(members_data)})
    except Exception as e:
        logger.error(f"Error in test team members: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@shift_swap_leave_bp.route('/api/user-shift-details')
@login_required
def get_user_shift_details():
    """Get specific shift details for a user on a specific date"""
    try:
        # STRICT REQUIREMENT: Current user must have team_id and account_id
        if not current_user.team_id or not current_user.account_id:
            return jsonify({
                'success': False, 
                'error': 'User must be assigned to a team and account'
            }), 403
        
        user_id = request.args.get('user_id')
        shift_date_str = request.args.get('date')
        
        if not user_id or not shift_date_str:
            return jsonify({'success': False, 'error': 'Missing user_id or date parameter'}), 400
        
        try:
            user_id = int(user_id)
            shift_date = datetime.strptime(shift_date_str, '%Y-%m-%d').date()
        except (ValueError, TypeError):
            return jsonify({'success': False, 'error': 'Invalid user_id or date format'}), 400
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'success': False, 'error': 'User not found'}), 404
        
        # STRICT ISOLATION: Can only view shifts of users in same team and account
        if user.team_id != current_user.team_id or user.account_id != current_user.account_id:
            logger.warning(f"User {current_user.username} attempted to access shift details of user {user.username} from different team/account")
            return jsonify({'success': False, 'error': 'Access denied - can only view shifts within your team'}), 403
        
        team_member = TeamMember.query.filter_by(
            name=user.username,
            account_id=current_user.account_id,
            team_id=current_user.team_id
        ).first()
        
        if not team_member:
            return jsonify({
                'success': True, 
                'shift': None,
                'message': 'User not found in team roster'
            })
        
        # Get shift for the specific date
        shift_roster = ShiftRoster.query.filter(
            ShiftRoster.team_member_id == team_member.id,
            ShiftRoster.date == shift_date,
            ShiftRoster.account_id == current_user.account_id,
            ShiftRoster.team_id == current_user.team_id
        ).first()
        
        if shift_roster:
            # Get shift timing from shift codes configuration
            shift_timings = {
                'DAY': '06:00 - 14:00',
                'EVENING': '14:00 - 22:00', 
                'NIGHT': '22:00 - 06:00',
                'MORNING': '06:00 - 14:00',
                'OFF': 'No shift',
                'N': '22:00 - 06:00'  # Handle 'N' shift code
            }
            
            return jsonify({
                'success': True,
                'shift': {
                    'shift_code': shift_roster.shift_code,
                    'timing': shift_timings.get(shift_roster.shift_code, f'{shift_roster.shift_code} shift'),
                    'date': shift_date.isoformat()
                }
            })
        else:
            return jsonify({
                'success': True,
                'shift': None,
                'message': 'No shift scheduled for this date'
            })
    
    except Exception as e:
        logger.error(f"Error getting user shift details: {str(e)}")
        return jsonify({'success': False, 'error': 'An error occurred'}), 500

@shift_swap_leave_bp.route('/api/available-engineers')
@login_required
def get_available_engineers():
    """Get available engineers for swap on a specific date"""
    try:
        # STRICT REQUIREMENT: Current user must have team_id and account_id
        if not current_user.team_id or not current_user.account_id:
            return jsonify({
                'success': False, 
                'error': 'User must be assigned to a team and account'
            }), 403
        
        shift_date_str = request.args.get('date')
        exclude_user_id = request.args.get('exclude_user_id')
        
        if not shift_date_str:
            return jsonify({'success': False, 'error': 'Missing date parameter'}), 400
        
        try:
            shift_date = datetime.strptime(shift_date_str, '%Y-%m-%d').date()
            exclude_user_id = int(exclude_user_id) if exclude_user_id else None
        except (ValueError, TypeError):
            return jsonify({'success': False, 'error': 'Invalid date format or user_id'}), 400
        
        # Get team members directly from team_member table
        team_members_query = TeamMember.query.filter(
            TeamMember.account_id == current_user.account_id,
            TeamMember.team_id == current_user.team_id
        )
        
        team_members = team_members_query.all()
        
        available_engineers = []
        for team_member in team_members:
            # Find corresponding user - try exact match first, then fuzzy match
            user = User.query.filter(
                User.username == team_member.name,
                User.account_id == current_user.account_id,
                User.team_id == current_user.team_id,
                User.is_active == True
            ).first()
            
            # If no exact match, try to find by converting team member name to username format
            if not user:
                # Convert "John Doe" to "john.doe" format
                username_format = team_member.name.lower().replace(' ', '.')
                user = User.query.filter(
                    User.username == username_format,
                    User.account_id == current_user.account_id,
                    User.team_id == current_user.team_id,
                    User.is_active == True
                ).first()
            
            # If still no match, try to find by first_name last_name combination
            if not user and ' ' in team_member.name:
                name_parts = team_member.name.split(' ', 1)
                if len(name_parts) == 2:
                    first_name, last_name = name_parts
                    user = User.query.filter(
                        User.first_name.ilike(first_name),
                        User.last_name.ilike(last_name),
                        User.account_id == current_user.account_id,
                        User.team_id == current_user.team_id,
                        User.is_active == True
                    ).first()
            
            # Skip if no corresponding active user or if it's the excluded user
            if not user or (exclude_user_id and user.id == exclude_user_id):
                continue
            
            # Get their shift for the selected date
            current_shift = 'Off'
            shift_roster = ShiftRoster.query.filter(
                ShiftRoster.team_member_id == team_member.id,
                ShiftRoster.date == shift_date,
                ShiftRoster.account_id == current_user.account_id,
                ShiftRoster.team_id == current_user.team_id
            ).first()
            
            if shift_roster:
                current_shift = shift_roster.shift_code
            
            # Prioritize team member name for display, but format properly
            display_name = team_member.name
            
            # If team member name looks like a username (has dots or underscores), use user's proper name
            if ('.' in team_member.name or '_' in team_member.name) and not ' ' in team_member.name:
                if user.first_name and user.last_name:
                    display_name = f"{user.first_name} {user.last_name}"
                elif user.first_name:
                    display_name = user.first_name
            
            # If team member name is in proper format (First Last), keep it as is
            # This ensures team member names like "John Doe" are displayed correctly
            
            available_engineers.append({
                'id': user.id,
                'username': user.username,
                'full_name': display_name,
                'current_shift': current_shift
            })
        
        return jsonify({
            'success': True,
            'engineers': available_engineers
        })
    
    except Exception as e:
        logger.error(f"Error getting available engineers: {str(e)}")
        return jsonify({'success': False, 'error': 'An error occurred'}), 500

@shift_swap_leave_bp.route('/simple-swap-request', methods=['GET', 'POST'])
@login_required
def simple_swap_request():
    """Simplified shift swap request form"""
    if request.method == 'POST':
        try:
            # Get form data
            swap_date_str = request.form.get('swap_date')
            from_engineer_id = request.form.get('from_engineer_id')
            original_shift_code = request.form.get('original_shift_code')
            swap_with_engineer_id = request.form.get('swap_with_engineer_id')
            
            # Validate required fields
            if not all([swap_date_str, from_engineer_id, swap_with_engineer_id]):
                flash('All fields are required.', 'error')
                return redirect(url_for('shift_swap_leave.simple_swap_request'))
            
            # Parse date
            try:
                swap_date = datetime.strptime(swap_date_str, '%Y-%m-%d').date()
            except ValueError:
                flash('Invalid date format.', 'error')
                return redirect(url_for('shift_swap_leave.simple_swap_request'))
            
            # Validate that user can only create requests for themselves unless admin
            if current_user.role not in ['super_admin', 'account_admin', 'team_admin']:
                if int(from_engineer_id) != current_user.id:
                    flash('You can only create swap requests for yourself.', 'error')
                    return redirect(url_for('shift_swap_leave.simple_swap_request'))
            
            # Get the target engineer's shift for the same date
            swap_with_user = User.query.get(int(swap_with_engineer_id))
            if not swap_with_user:
                flash('Selected engineer not found.', 'error')
                return redirect(url_for('shift_swap_leave.simple_swap_request'))
            
            # Get swap partner's shift for the same date
            swap_with_team_member = TeamMember.query.filter_by(
                name=swap_with_user.username,
                account_id=current_user.account_id,
                team_id=current_user.team_id
            ).first()
            
            swap_partner_shift = 'OFF'
            if swap_with_team_member:
                partner_roster = ShiftRoster.query.filter(
                    ShiftRoster.team_member_id == swap_with_team_member.id,
                    ShiftRoster.date == swap_date,
                    ShiftRoster.account_id == current_user.account_id,
                    ShiftRoster.team_id == current_user.team_id
                ).first()
                
                if partner_roster:
                    swap_partner_shift = partner_roster.shift_code
            
            # Create swap request with automatic reason
            reason = f"Shift swap request for {swap_date.strftime('%Y-%m-%d')} - System generated request"
            
            result = shift_swap_leave_service.create_shift_swap_request(
                requester_id=int(from_engineer_id),
                swap_with_id=int(swap_with_engineer_id),
                original_date=swap_date,
                original_shift_code=original_shift_code or 'OFF',
                swap_date=swap_date,  # Same date swap
                swap_shift_code=swap_partner_shift,
                reason=reason
            )
            
            if result['success']:
                flash('Shift swap request submitted successfully!', 'success')
                return redirect(url_for('shift_swap_leave.dashboard'))
            else:
                flash(f'Error: {result["error"]}', 'error')
                
        except Exception as e:
            logger.error(f"Error processing simple swap request: {str(e)}")
            flash('An error occurred while processing your request. Please try again.', 'error')
    
    # GET request - render form
    from datetime import timedelta
    today = date.today()
    min_date = today.isoformat()
    max_date = (today + timedelta(days=90)).isoformat()
    
    # Get team members for admin dropdown
    team_members = []
    if current_user.role in ['super_admin', 'account_admin', 'team_admin']:
        team_members = User.query.filter(
            User.account_id == current_user.account_id,
            User.team_id == current_user.team_id,
            User.is_active == True,
            User.role.in_(['user', 'engineer', 'team_admin'])
        ).all()
        
        team_members = [{
            'id': user.id,
            'full_name': f"{user.first_name} {user.last_name}"
        } for user in team_members]
    
    return render_template('shift_management/simple_swap_request.html', 
                         current_user=current_user,
                         min_date=min_date,
                         max_date=max_date,
                         team_members=team_members)

# Error handlers
@shift_swap_leave_bp.errorhandler(404)
def not_found(error):
    return jsonify({'success': False, 'error': 'Resource not found'}), 404

@shift_swap_leave_bp.errorhandler(500)
def internal_error(error):
    logger.error(f"Internal server error: {str(error)}")
    return jsonify({'success': False, 'error': 'Internal server error'}), 500
@shift_swap_leave_bp.route("/api/user-shift/<date>", methods=["GET"])
@login_required
def get_user_shift_for_date(date):
    """Get user's scheduled shift for a specific date"""
    try:
        from datetime import datetime
        from models.models import ShiftRoster, TeamMember
        
        # Parse the date
        try:
            leave_date = datetime.strptime(date, "%Y-%m-%d").date()
        except ValueError:
            return jsonify({"success": False, "error": "Invalid date format"}), 400
        
        # Get user's team member record
        team_member = TeamMember.query.filter_by(user_id=current_user.id).first()
        if not team_member:
            return jsonify({"success": False, "error": "Team member record not found"}), 404
        
        # Get scheduled shift for the date - try without account_id first, then with
        roster_entry = ShiftRoster.query.filter_by(
            date=leave_date,
            team_member_id=team_member.id
        ).first()

        # If not found and user has account_id, try with account_id filter
        if not roster_entry and current_user.account_id:
            roster_entry = ShiftRoster.query.filter_by(
                date=leave_date,
                team_member_id=team_member.id,
                account_id=current_user.account_id
            ).first()
        
        if roster_entry:
            shift_names = {
                "D": "Day Shift",
                "E": "Evening Shift", 
                "N": "Night Shift",
                "OS": "On-Site",
                "OF": "Off Duty",
                "O": "Week Off"
            }
            
            return jsonify({
                "success": True,
                "shift": {
                    "code": roster_entry.shift_code,
                    "name": shift_names.get(roster_entry.shift_code, roster_entry.shift_code)
                },
                "date": date
            })
        else:
            # Debug info to help troubleshoot
            print(f"DEBUG: No roster entry found for user {current_user.id}, team_member {team_member.id}, date {leave_date}")
            
            return jsonify({
                "success": True,
                "shift": None,
                "message": "No shift scheduled for this date"
            })
            
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
